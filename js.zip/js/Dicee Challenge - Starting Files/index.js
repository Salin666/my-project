
 var numberOfDice = Math.floor(Math.random() * 6) + 1; //number 1 to 6 in integer

var dice1Image =  "dice" + numberOfDice + ".png"; //  six dice picture

var diceSource = "images/" + dice1Image; //source

var dice1 =document.querySelectorAll("img")[0]; //select dice 1

dice1.setAttribute("src", diceSource);
//--------------------------------------end of dice one---------------------------------------


//-----------------------------    start of dice 2--------------------------------------------
var numberOfDice2 = Math.floor(Math.random() * 6) + 1; //number 1 to 6 in integer

var diceSource2 = "images/dice" + numberOfDice2 + ".png";

document.querySelectorAll("img")[1].setAttribute("src", diceSource2); //select dice 1

//----------------------------------end of dice 2-------------------------------------------

//---------------------------------conditional -------------------------------------------
if (numberOfDice > numberOfDice2) {
  document.querySelector("h1").innerHTML = "🚩 Play 1 Wins!";
}
else if (numberOfDice < numberOfDice2) {
  document.querySelector("h1").innerHTML = "Player 2 Wins! 🚩";
}
else {
  document.querySelector("h1").innerHTML = "Draw!";
}
