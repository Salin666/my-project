const express = require("express");

const app = express() // a function that represents module

app.get("/", function(req,res){
res.send("<h1>Server is running</h1>");
});

app.get("/about", function(req,res){
  res.send("<h1>this is a about page</h1>")
})

app.listen(3000, function(){
  console.log("port 3000 is running"); // call back function
}); //sending a request to http
