const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");

const app = express();
app.get("/", function(req,res){
  res.sendFile(__dirname + "/index.html")
});
app.use(bodyParser.urlencoded({extended:true}));


app.use(express.static("public"));

app.post("/", function(req,res){
  const firstName = req.body.fName;
  const lastName = req.body.lName;
  const email = req.body.email;

  const data = {
    members: [
      {
        email_address:email,
        status: "subscribed",
        FNAME:firstName,
        LNAME:lastName,
      }
    ]
  }

var jsonData = JSON.stringify(data);// changing the json a line statement

const url ="https://us5.api.mailchimp.com/3.0/lists/8d833ca894";

const options = {
  method: "POST",
  auth: "san1:9f60ad213379547bbcb0811ef24092f6-us5"

}

const request(url,options, function(response){
response.on("data", function(data){
  console.log(JSON.parse(data));
})
})
resquest.write(jsonData);
  //  console.log(firstName, lastName, email); //important show on node js
})

app.listen(3000, function(){
  console.log("server is running!");
});

//api key
//9f60ad213379547bbcb0811ef24092f6-us5
//there several us url from us1-20

//audience id
//8d833ca894
