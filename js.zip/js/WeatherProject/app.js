const express = require("express")
const http = require("https");
const bodyParser = require("body-parser")// fetch the data that the form input
const app = express();
app.use(bodyParser.urlencoded({extended:true}));

app.get("/",function(req, res){
  res.sendFile(__dirname + "/index.html");

  app.post("/", function(req, res){
      const place = req.body.cityName;
      console.log(req.body.cityName);
    const apiKey = "4eba4ed777f9d872577aa8b3ea7d4e06";
    const unit = "metric";

  const url = "https://api.openweathermap.org/data/2.5/weather?q=" + place + "&appid=" + apiKey + "&units=" + unit;
     http.get(url, function(response){
       console.log(response.statusCode); // find the status of the port

      response.on("data", function(data){  //get the data of what the weather app sent us
      const weatherData = JSON.parse(data)  //show it in jason
       const temp1 = weatherData.main.temp
      const weather =  weatherData.weather[0].description;
      const icon = weatherData.weather[0].icon;
       const weatherImage = "http://openweathermap.org/img/wn/"  + icon + "@2x.png";

       // show in browser
    res.write("<h1> The temperature in" + place + "is " + temp1 + "degress Celcius</h1>")
    res.write(" <h3>The weather in " + place + " is " +  weather + "</h3>");
    res.write("<img src =" + weatherImage +">");
    res.send();
  })
            })
  })
})
app.listen(3000,function(){

  console.log("the server of port 3000 is running")
})
