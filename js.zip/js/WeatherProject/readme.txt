install 
npm i body-parser

fetch the data of the input data in the front end