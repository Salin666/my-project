import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
function App() {
  return (
    <div>
      <Header />
      <Note/>
      <Footer/>
      <h1>Hello App</h1>
    </div>
  );
}

export default App;
